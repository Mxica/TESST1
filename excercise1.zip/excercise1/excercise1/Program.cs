﻿using System;

namespace exercise1
{
    class Program
    {
        static void Main(string[] args)
        {
            double eBase = 0;
            double eResult = 1;
            int ePower = 0;
            int eCount = 1;

            Console.Write("Enter BASE: ");
            eBase = double.Parse(Console.ReadLine());
            Console.Write("Enter POWER: ");
            ePower = int.Parse(Console.ReadLine());
            do
            {
                eResult = eResult * eBase;
                eCount++;
            } while (eCount <= ePower);

            Console.WriteLine("Result: {0}", eResult);
        }
    }
}