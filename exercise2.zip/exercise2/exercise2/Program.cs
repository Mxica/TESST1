﻿using System;

namespace exercise2
{
    class Program
    {
        static void Main(string[] args)
        {
            int eCount = 0;
            double ePrice = 0;
            double eTotal = 0;

            for (eCount = 0; eCount < 5; eCount++)
            {
                Console.WriteLine("Enter price of product {0}: ", eCount + 1);
                ePrice = double.Parse(Console.ReadLine());
                eTotal = eTotal + ePrice;
            }

            Console.WriteLine("The total price is ${0:0.00}.", eTotal);
        }
    }
}