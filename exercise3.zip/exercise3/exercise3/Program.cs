﻿using System;

namespace exercise3
{
    class Program
    {
        // 2(x + 3) + x = 12
        // 2x + 6 + x = 12
        // 3x = 6
        // x = 2
        static void Main(string[] args)
        {
            int answer = 2;
            int guess = 0;

            Console.WriteLine("Can you solve the following algebraic expression: 2( x + 3) + x = 12");
            Console.Write("Enter your guess at the value of x: ");
            guess = int.Parse(Console.ReadLine());
            if (guess == answer)
            {
                Console.WriteLine("Your guess is correct!");
            }
            else
            {
                Console.WriteLine("Your guess is incorrect!");
            }
        }
    }
}